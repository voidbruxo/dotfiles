return{  'karshPrime/only-tmux.nvim',
    event = 'VeryLazy',
    config = { new_window_name = "session" } -- optional
};
