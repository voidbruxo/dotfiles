return {
  'tanvirtin/vgit.nvim',
  requires = {
    'nvim-lua/plenary.nvim',
  },
}
